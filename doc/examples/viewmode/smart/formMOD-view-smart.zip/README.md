<img src="https://nickorsk2017.github.io/formMOD/public/formModLogo.svg">

This is example from page of formMOD documentation.

## Installation

Intallation with npm:
```bash
npm i
```

Intallation with yarn:
```bash
yarn install
```
## Quick Start

```bash
npm run start
```

```bash
yarn start
```

Then open http://localhost:3000/ to see example.

## License
MIT
