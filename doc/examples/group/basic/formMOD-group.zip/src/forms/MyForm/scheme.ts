export default {
    valid: null,
    formValue: {
        hobbies: []
    },
    rules: {
        hobbies: [
            ["empty", "please describe your hobby"]
        ]
    }
}